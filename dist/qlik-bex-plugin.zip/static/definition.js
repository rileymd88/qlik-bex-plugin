export default {
  type: "items",
  component: "accordion",
  items: {
    settings: {
      uses: "settings"
    }
  }
}